import { configureStore, combineReducers } from "@reduxjs/toolkit";
import userslice from "./userslice";


const rootReducer = combineReducers({
  reducer:userslice,
});

const store = configureStore({
  reducer:rootReducer,
})

export default store; 
