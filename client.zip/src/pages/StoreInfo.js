import React from "react";

const StoreInfo = () => {
  return <div>StoreInfo</div>;
};

export default StoreInfo;
