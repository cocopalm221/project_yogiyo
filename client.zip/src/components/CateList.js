import React from "react";

const CateList = () => {
  return <div>CateList</div>;
};

export default CateList;
