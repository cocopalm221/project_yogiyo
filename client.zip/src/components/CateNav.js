import React from "react";
const CateNav = () => {
  return <div></div>;
};

export default CateNav;
